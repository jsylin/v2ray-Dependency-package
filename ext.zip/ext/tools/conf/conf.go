package conf

//go:generate errorgen
