package serial

//go:generate errorgen
