package control

//go:generate errorgen
