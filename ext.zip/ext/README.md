# V2Ray Extensions

[![Build Status][1]][2] [![codecov.io][3]][4] [![codebeat badge][5]][6]

[1]: https://dev.azure.com/v2ray/core/_apis/build/status/v2ray.ext "Build Status badge"
[2]: https://dev.azure.com/v2ray/core/_build/latest?definitionId=2 "Build Status link"
[3]: https://codecov.io/github/v2ray/ext/coverage.svg?branch=master "Coverage badge"
[4]: https://codecov.io/github/v2ray/ext?branch=master "Codecov Status"
[5]: https://codebeat.co/badges/3a2163a8-cb1a-41ba-a860-bf60e2fa5050 "CodeBeat badge"
[6]: https://codebeat.co/projects/github-com-v2ray-ext-master "CodeBeat status"

More utilities
