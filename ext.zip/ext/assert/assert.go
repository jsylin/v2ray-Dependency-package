package assert

func NotUsedAnyMore() {}
